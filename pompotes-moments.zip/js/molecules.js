/* ------------------------------------------------------------------
   Dessins de molécules (formules topologiques simplifiées)
   Format : atomes {nom:[x, y, 'étiquette?']} et liaisons ['a-b', 'a=b']
   1 unité = 1 longueur de liaison. Le rendu SVG est généré à l'exécution.
------------------------------------------------------------------- */
(function () {
  const S = 44;            // pixels par unité de liaison
  const GAP = 0.3;         // raccourcissement des liaisons près d'une étiquette

  const DEFS = {
    /* Mélatonine : indole + méthoxy + chaîne N-acétyléthylamine */
    melatonine: {
      atoms: {
        C4: [0, -1], C5: [-0.866, -0.5], C6: [-0.866, 0.5], C7: [0, 1], C7a: [0.866, 0.5], C3a: [0.866, -0.5],
        N1: [1.817, 0.809, 'NH'], C2: [2.405, 0], C3: [1.817, -0.809],
        O5: [-1.732, -1, 'O'], Me: [-2.598, -0.5],
        Ca: [2.126, -1.76], Cb: [2.992, -2.26], Nn: [3.858, -1.76, 'NH'], Cc: [4.724, -2.26],
        Oc: [4.724, -3.26, 'O'], Cm: [5.59, -1.76]
      },
      bonds: ['C4=C5', 'C5-C6', 'C6=C7', 'C7-C7a', 'C7a=C3a', 'C3a-C4', 'C3a-C3', 'C3=C2', 'C2-N1', 'N1-C7a',
        'C5-O5', 'O5-Me', 'C3-Ca', 'Ca-Cb', 'Cb-Nn', 'Nn-Cc', 'Cc=Oc', 'Cc-Cm']
    },

    /* Acide rosmarinique : l'actif phare de la mélisse */
    rosmarinique: {
      atoms: {
        Ta: [0, -1], TRa: [0.866, -0.5], BRa: [0.866, 0.5], Ba: [0, 1], BLa: [-0.866, 0.5], TLa: [-0.866, -0.5],
        OHa1: [0, -2, 'OH'], OHa2: [-1.732, -1, 'OH'],
        Ca: [1.732, 1], Cb: [2.598, 0.5], Cc: [3.464, 1], Oc: [3.464, 2, 'O'], Oe: [4.33, 0.5, 'O'],
        Cd: [5.196, 1], Ce: [5.196, 2], Oe1: [4.33, 2.5, 'OH'], Oe2: [6.062, 2.5, 'O'], Cf: [6.062, 0.5],
        Tb: [7.794, 0.5], TRb: [8.66, 1], BRb: [8.66, 2], Bb: [7.794, 2.5], BLb: [6.928, 2], TLb: [6.928, 1],
        OHb1: [9.526, 2.5, 'OH'], OHb2: [7.794, 3.5, 'OH']
      },
      bonds: ['TRa=BRa', 'BRa-Ba', 'Ba=BLa', 'BLa-TLa', 'TLa=Ta', 'Ta-TRa', 'Ta-OHa1', 'TLa-OHa2',
        'BRa-Ca', 'Ca=Cb', 'Cb-Cc', 'Cc=Oc', 'Cc-Oe', 'Oe-Cd', 'Cd-Ce', 'Ce-Oe1', 'Ce=Oe2', 'Cd-Cf', 'Cf-TLb',
        'TLb=Tb', 'Tb-TRb', 'TRb=BRb', 'BRb-Bb', 'Bb=BLb', 'BLb-TLb', 'BRb-OHb1', 'Bb-OHb2']
    },

    /* Ginsénoside (structure simplifiée) : noyau dammarane + sucre */
    ginsenoside: {
      atoms: {
        AT: [0, -1], ATR: [0.866, -0.5], ABR: [0.866, 0.5], AB: [0, 1], ABL: [-0.866, 0.5], ATL: [-0.866, -0.5],
        BT: [1.732, -1], BTR: [2.598, -0.5], BBR: [2.598, 0.5], BB: [1.732, 1],
        CT: [2.598, -2.5], CTR: [3.464, -2], CBR: [3.464, -1], CTL: [1.732, -2],
        D1: [4.415, -0.691], D2: [5.003, -1.5], D3: [4.415, -2.309],
        C20: [4.724, -3.26], O20: [3.94, -3.89, 'OH'], C22: [5.59, -3.76], C23: [6.456, -3.26],
        C24: [7.322, -3.76], C25: [8.188, -3.26], C26: [8.188, -2.26], C27: [9.054, -3.76],
        Me10: [0.866, -1.5], Me13: [3.464, -3],
        O3: [-1.732, 1, 'O'],
        g1: [-2.598, 1.5], gO: [-2.598, 0.5, 'O'], g5: [-3.464, 0], g4: [-4.33, 0.5], g3: [-4.33, 1.5], g2: [-3.464, 2],
        gO2: [-3.464, 3, 'OH'], gO3: [-5.196, 2, 'OH'], gO4: [-5.196, 0, 'OH'], g6: [-3.464, -1], gO6: [-2.598, -1.5, 'OH']
      },
      bonds: ['AT-ATR', 'ATR-ABR', 'ABR-AB', 'AB-ABL', 'ABL-ATL', 'ATL-AT',
        'ATR-BT', 'BT-BTR', 'BTR-BBR', 'BBR-BB', 'BB-ABR',
        'BT-CTL', 'CTL-CT', 'CT-CTR', 'CTR-CBR', 'CBR-BTR',
        'CTR-D3', 'D3-D2', 'D2-D1', 'D1-CBR',
        'D3-C20', 'C20-O20', 'C20-C22', 'C22-C23', 'C23-C24', 'C24=C25', 'C25-C26', 'C25-C27',
        'ATR-Me10', 'CTR-Me13',
        'ABL-O3', 'O3-g1', 'g1-gO', 'gO-g5', 'g5-g4', 'g4-g3', 'g3-g2', 'g2-g1',
        'g2-gO2', 'g3-gO3', 'g4-gO4', 'g5-g6', 'g6-gO6']
    },

    /* Acide ascorbique (vitamine C) */
    vitc: {
      atoms: {
        O1: [0, -0.851, 'O'], C1: [0.809, -0.263], C2: [0.5, 0.688], C3: [-0.5, 0.688], C4: [-0.809, -0.263],
        Oc1: [1.76, -0.572, 'O'], O2h: [1.088, 1.497, 'OH'], O3h: [-1.088, 1.497, 'OH'],
        C5: [-1.76, -0.572], O5h: [-1.76, -1.572, 'OH'], C6: [-2.626, -0.072], O6h: [-3.492, -0.572, 'OH']
      },
      bonds: ['O1-C1', 'C1-C2', 'C2=C3', 'C3-C4', 'C4-O1', 'C1=Oc1', 'C2-O2h', 'C3-O3h', 'C4-C5', 'C5-O5h', 'C5-C6', 'C6-O6h']
    },

    /* Pyridoxine (vitamine B6) */
    vitb6: {
      atoms: {
        N: [0, 1, 'N'], C2: [-0.866, 0.5], C3: [-0.866, -0.5], C4: [0, -1], C5: [0.866, -0.5], C6: [0.866, 0.5],
        Me2: [-1.732, 1], O3: [-1.732, -1, 'OH'], C4a: [0, -2], O4a: [0.866, -2.5, 'OH'],
        C5a: [1.732, -1], O5a: [2.598, -1.5, 'OH']
      },
      bonds: ['N=C2', 'C2-C3', 'C3=C4', 'C4-C5', 'C5=C6', 'C6-N', 'C2-Me2', 'C3-O3', 'C4-C4a', 'C4a-O4a', 'C5-C5a', 'C5a-O5a']
    },

    /* Safranal : l'arôme principal du safran */
    safranal: {
      atoms: {
        C1: [0.866, -0.5], C2: [0, -1], C3: [-0.866, -0.5], C4: [-0.866, 0.5], C5: [0, 1], C6: [0.866, 0.5],
        CHO: [1.732, -1], O: [1.732, -2, 'O'], Me2: [0, -2], Me6a: [1.732, 1], Me6b: [0.866, 1.5]
      },
      bonds: ['C1=C2', 'C2-C3', 'C3=C4', 'C4-C5', 'C5-C6', 'C6-C1', 'C1-CHO', 'CHO=O', 'C2-Me2', 'C6-Me6a', 'C6-Me6b']
    },

    /* Salidroside : l'actif de la rhodiola */
    salidroside: {
      atoms: {
        T: [0, -1], TR: [0.866, -0.5], BR: [0.866, 0.5], B: [0, 1], BL: [-0.866, 0.5], TL: [-0.866, -0.5],
        OH: [-1.732, -1, 'OH'], Ca: [1.732, 1], Cb: [2.598, 0.5], Oe: [3.464, 1, 'O'],
        g1: [4.33, 0.5], gO: [5.196, 0, 'O'], g5: [6.062, 0.5], g4: [6.062, 1.5], g3: [5.196, 2], g2: [4.33, 1.5],
        gO2: [3.464, 2, 'OH'], gO3: [5.196, 3, 'OH'], gO4: [6.928, 2, 'OH'], g6: [6.928, 0], gO6: [7.794, 0.5, 'OH']
      },
      bonds: ['TL=T', 'T-TR', 'TR=BR', 'BR-B', 'B=BL', 'BL-TL', 'TL-OH', 'BR-Ca', 'Ca-Cb', 'Cb-Oe', 'Oe-g1',
        'g1-gO', 'gO-g5', 'g5-g4', 'g4-g3', 'g3-g2', 'g2-g1', 'g2-gO2', 'g3-gO3', 'g4-gO4', 'g5-g6', 'g6-gO6']
    }
  };

  /* ---------- rendu générique ---------- */
  function render(def) {
    const names = Object.keys(def.atoms);
    const pos = {}, lab = {};
    names.forEach(n => { pos[n] = [def.atoms[n][0] * S, def.atoms[n][1] * S]; lab[n] = def.atoms[n][2] || ''; });
    const bonds = def.bonds.map(b => {
      const m = b.match(/^(\w+)([-=])(\w+)$/);
      return { a: m[1], b: m[3], o: m[2] === '=' ? 2 : 1 };
    });
    const nb = {};
    bonds.forEach(b => { (nb[b.a] = nb[b.a] || []).push(b.b); (nb[b.b] = nb[b.b] || []).push(b.a); });

    let minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
    names.forEach(n => {
      const [x, y] = pos[n];
      minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y);
    });
    const pad = 26;
    const vb = `${minX - pad} ${minY - pad} ${maxX - minX + 2 * pad} ${maxY - minY + 2 * pad}`;

    let lines = '', idx = 0;
    const shorten = (p, q, an) => {           // raccourcit p vers q si p a une étiquette
      if (!lab[an]) return p;
      const dx = q[0] - p[0], dy = q[1] - p[1], L = Math.hypot(dx, dy);
      const g = GAP * S;
      return [p[0] + dx / L * g, p[1] + dy / L * g];
    };
    bonds.forEach(bd => {
      const P = pos[bd.a], Q = pos[bd.b];
      const p1 = shorten(P, Q, bd.a), p2 = shorten(Q, P, bd.b);
      const d = idx++ * 0.055;
      const ln = (a, b, extra = '') =>
        `<line class="bond" x1="${a[0].toFixed(1)}" y1="${a[1].toFixed(1)}" x2="${b[0].toFixed(1)}" y2="${b[1].toFixed(1)}" pathLength="1" style="animation-delay:${d.toFixed(2)}s" ${extra}/>`;
      if (bd.o === 1) { lines += ln(p1, p2); return; }
      // double liaison : 2e trait décalé vers l'intérieur
      const dx = Q[0] - P[0], dy = Q[1] - P[1], L = Math.hypot(dx, dy);
      let nx = -dy / L, ny = dx / L;
      const others = [...(nb[bd.a] || []), ...(nb[bd.b] || [])].filter(n => n !== bd.a && n !== bd.b);
      let cx = (P[0] + Q[0]) / 2, cy = (P[1] + Q[1]) / 2;
      if (others.length) {
        const ox = others.reduce((s, n) => s + pos[n][0], 0) / others.length;
        const oy = others.reduce((s, n) => s + pos[n][1], 0) / others.length;
        if ((ox - cx) * nx + (oy - cy) * ny < 0) { nx = -nx; ny = -ny; }
      }
      const off = 0.13 * S, sh = 0.14 * S;
      const ux = dx / L, uy = dy / L;
      const a2 = [p1[0] + nx * off + (lab[bd.a] ? 0 : ux * sh), p1[1] + ny * off + (lab[bd.a] ? 0 : uy * sh)];
      const b2 = [p2[0] + nx * off - (lab[bd.b] ? 0 : ux * sh), p2[1] + ny * off - (lab[bd.b] ? 0 : uy * sh)];
      // liaisons doubles terminales (C=O) : deux traits symétriques
      if (others.length <= 1 && (lab[bd.a] || lab[bd.b])) {
        const s1 = [p1[0] + nx * off / 1.6, p1[1] + ny * off / 1.6], s2 = [p2[0] + nx * off / 1.6, p2[1] + ny * off / 1.6];
        const t1 = [p1[0] - nx * off / 1.6, p1[1] - ny * off / 1.6], t2 = [p2[0] - nx * off / 1.6, p2[1] - ny * off / 1.6];
        lines += ln(s1, s2) + ln(t1, t2); return;
      }
      lines += ln(p1, p2) + ln(a2, b2);
    });
    let text = '';
    names.forEach(n => {
      if (!lab[n]) return;
      const [x, y] = pos[n];
      text += `<text class="atom" x="${x.toFixed(1)}" y="${y.toFixed(1)}" text-anchor="middle" dominant-baseline="central">${lab[n]}</text>`;
    });
    return { vb, inner: lines + text };
  }

  /* ---------- Vitamine B12 (corrine + cobalt) : dessin stylisé ---------- */
  function renderB12() {
    const R = 22, D = 62, pts = [];
    let inner = '', k = 0;
    const pent = [];
    for (let i = 0; i < 4; i++) {
      const dir = i * Math.PI / 2;
      const cx = Math.cos(dir) * D, cy = Math.sin(dir) * D;
      const vs = [];
      for (let j = 0; j < 5; j++) {
        const a = dir + Math.PI + j * 2 * Math.PI / 5;
        vs.push([cx + Math.cos(a) * R, cy + Math.sin(a) * R]);
      }
      pent.push(vs);
      for (let j = 0; j < 5; j++) {
        const A = vs[j], B = vs[(j + 1) % 5];
        const isDouble = (j === 2);
        inner += `<line class="bond" x1="${A[0].toFixed(1)}" y1="${A[1].toFixed(1)}" x2="${B[0].toFixed(1)}" y2="${B[1].toFixed(1)}" pathLength="1" style="animation-delay:${(k++ * 0.05).toFixed(2)}s"/>`;
        if (isDouble) {
          const mx = (A[0] + B[0]) / 2, my = (A[1] + B[1]) / 2;
          const vx = cx - mx, vy = cy - my, l = Math.hypot(vx, vy);
          const o = 5;
          inner += `<line class="bond" x1="${(A[0] + vx / l * o).toFixed(1)}" y1="${(A[1] + vy / l * o).toFixed(1)}" x2="${(B[0] + vx / l * o).toFixed(1)}" y2="${(B[1] + vy / l * o).toFixed(1)}" pathLength="1" style="animation-delay:${(k++ * 0.05).toFixed(2)}s"/>`;
        }
      }
      // stub de chaîne latérale vers l'extérieur
      const out = vs[2];
      const ox = Math.cos(dir) * 18, oy = Math.sin(dir) * 18;
      inner += `<line class="bond" x1="${((vs[2][0] + vs[3][0]) / 2).toFixed(1)}" y1="${((vs[2][1] + vs[3][1]) / 2).toFixed(1)}" x2="${(((vs[2][0] + vs[3][0]) / 2) + Math.cos(dir + 0.9) * 24).toFixed(1)}" y2="${(((vs[2][1] + vs[3][1]) / 2) + Math.sin(dir + 0.9) * 24).toFixed(1)}" pathLength="1" style="animation-delay:${(k++ * 0.05).toFixed(2)}s"/>`;
    }
    // ponts entre cycles voisins (atomes les plus proches hors N interne)
    for (let i = 0; i < 4; i++) {
      const A = pent[i], B = pent[(i + 1) % 4];
      let best = null;
      for (let a = 1; a < 5; a++) for (let b = 1; b < 5; b++) {
        const d = Math.hypot(A[a][0] - B[b][0], A[a][1] - B[b][1]);
        if (!best || d < best.d) best = { d, a, b };
      }
      inner += `<line class="bond" x1="${A[best.a][0].toFixed(1)}" y1="${A[best.a][1].toFixed(1)}" x2="${B[best.b][0].toFixed(1)}" y2="${B[best.b][1].toFixed(1)}" pathLength="1" style="animation-delay:${(k++ * 0.05).toFixed(2)}s"/>`;
    }
    // liaisons de coordination N → Co (pointillées) + étiquettes
    for (let i = 0; i < 4; i++) {
      const n = pent[i][0];
      inner += `<line class="coord" x1="${n[0].toFixed(1)}" y1="${n[1].toFixed(1)}" x2="0" y2="0"/>`;
    }
    for (let i = 0; i < 4; i++) {
      const n = pent[i][0];
      inner += `<text class="atom" x="${n[0].toFixed(1)}" y="${n[1].toFixed(1)}" text-anchor="middle" dominant-baseline="central">N</text>`;
    }
    inner += `<circle class="co" cx="0" cy="0" r="15"/><text class="atom co-t" x="0" y="1" text-anchor="middle" dominant-baseline="central">Co</text>`;
    return { vb: '-112 -112 224 224', inner };
  }

  /* ---------- Fer : case du tableau périodique + orbites ---------- */
  function renderFe() {
    const inner = `
      <g class="orbits">
        <ellipse class="orb" cx="0" cy="0" rx="92" ry="34"/>
        <ellipse class="orb" cx="0" cy="0" rx="92" ry="34" transform="rotate(60)"/>
        <ellipse class="orb" cx="0" cy="0" rx="92" ry="34" transform="rotate(120)"/>
        <circle class="elec" cx="92" cy="0" r="4"/>
        <circle class="elec" cx="-92" cy="0" r="4" transform="rotate(60)"/>
        <circle class="elec" cx="92" cy="0" r="4" transform="rotate(120)"/>
      </g>
      <rect class="tile" x="-40" y="-46" width="80" height="92" rx="8"/>
      <text class="mono-s" x="-31" y="-31" dominant-baseline="central">26</text>
      <text class="sym" x="0" y="6" text-anchor="middle" dominant-baseline="central">Fe</text>
      <text class="mono-s" x="0" y="32" text-anchor="middle" dominant-baseline="central">55,845</text>`;
    return { vb: '-104 -84 208 168', inner };
  }

  window.MOLS = {
    melatonine: render(DEFS.melatonine),
    rosmarinique: render(DEFS.rosmarinique),
    ginsenoside: render(DEFS.ginsenoside),
    vitc: render(DEFS.vitc),
    vitb6: render(DEFS.vitb6),
    safranal: render(DEFS.safranal),
    salidroside: render(DEFS.salidroside),
    vitb12: renderB12(),
    fer: renderFe()
  };
})();
