/* =====================================================================
   POM'POTES MOMENTS — logique de la présentation
   ===================================================================== */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const icon = id => `<svg class="ic"><use href="#i-${id}"/></svg>`;

  /* ------------------------------------------------------------------
     DONNÉES
  ------------------------------------------------------------------- */
  // SWOT (transcrit du tableau fourni). Les éléments sont séparés ici pour le zoom.
  const SWOT = {
    rows: [
      { id: 'F', label: 'Forces', key: true, color: '#2f8f4e' },
      { id: 'W', label: 'Faiblesses', key: true, color: '#d04a86' },
      { id: 'O', label: 'Opportunités', key: false, color: '#d58f0c' },
      { id: 'T', label: 'Menaces', key: false, color: '#1f2c6e' }
    ],
    cols: [
      { id: 'M', label: 'Marketing', sub: 'offre, prix, distribution' },
      { id: 'C', label: 'Communication', sub: 'image, campagnes' }
    ],
    cells: {
      FM: {
        title: 'Un leader solide : n°1 des marques nationales',
        items: ['Pionnier de la gourde (1998), n°1 des marques nationales (≈ 28 %)', 'sans sucres ajoutés, Nutri-Score A, pommes 100 % France', 'gourde mono-matériau, Héli’bouchon refermable', 'gamme segmentée par cible', 'distribution large (GSA, drive, e-commerce, hors domicile)', 'groupe Bel'],
        figs: [['≈ 28 %', 'de part parmi les marques nationales'], ['1998', 'pionnier de la gourde']]
      },
      FC: {
        title: 'Une notoriété et une communication déjà très puissantes',
        items: ['Très forte notoriété', 'campagne 360° 2025 co-construite avec la Gen Z (prétest)', 'plan média TikTok, Instagram, BeReal, YouTube, DOOH', 'marketing d’influence (Roman Doduik, Lena Situations) et marketing expérientiel (Hôtel Mahfouf)', 'RSE visible (Unis-Cité, ColoSolidaire, Terracycle)'],
        figs: [['360°', 'campagne 2025 co-construite avec la Gen Z']]
      },
      WM: {
        title: 'Une offre pensée pour les familles, pas pour les 18-23 ans',
        items: ['88 % des volumes en lignes famille', 'lignes 18-30 ans peu développées (12 % avec les ados)', 'format unique de 90 g, adapté à un enfant plus qu’à un adulte', 'pas de bénéfice fonctionnel', 'prix au kilo élevé face aux MDD', 'absente des distributeurs automatiques'],
        figs: [['88 %', 'des volumes en lignes famille'], ['12 %', 'seulement avec les ados'], ['90 g', 'format unique, pensé pour un enfant']],
        callout: ['Notre enjeu n°1 : l’âge', 'La marque est pensée pour les familles. Aucune offre ne parle vraiment aux 18-23 ans.']
      },
      WC: {
        title: 'Une image d’enfance qui fait fuir la Gen Z',
        items: ['Image « enfant » : mascottes, packs colorés, jeux sous les gourdes', 'la Gen Z délaisse la marque en grandissant', 'campagne jeunes récente, efficacité à prouver dans la durée', 'frontière floue avec Materne'],
        figs: [],
        callout: ['Notre enjeu n°1 : l’âge', 'La Gen Z délaisse la marque en grandissant : c’est exactement le problème que Pom’Potes Moments doit résoudre.']
      },
      OM: {
        title: 'Un marché porteur et des attentes fonctionnelles',
        items: ['Gourdes en croissance (+5,4 %)', 'profil healthy surreprésenté chez les 18-34 ans', 'attente de bénéfices fonctionnels', '1 repas sur 5 hors domicile, e-commerce', 'précédent gamme « Active » aux États-Unis', 'peu d’acteurs ciblent vraiment les 18-23 ans'],
        figs: [['+5,4 %', 'croissance des gourdes'], ['1 / 5', 'repas pris hors domicile']]
      },
      OC: {
        title: 'Une génération nostalgique, connectée, en quête d’authenticité',
        items: ['Nostalgie de la Gen Z envers la marque', 'réseaux sociaux, streaming, influence', 'attentes d’authenticité et d’expériences immersives'],
        figs: []
      },
      TM: {
        title: 'Un contexte de prix et une concurrence qui se resserre',
        items: ['MDD (≈ 36 %) en période d’inflation', 'Andros et Charles & Alice sur les jeunes adultes', 'banalisation du « sans sucres ajoutés »', 'coût des fruits (récoltes 2025)', 'baisse de la natalité'],
        figs: [['≈ 36 %', 'de marques de distributeur (MDD)']]
      },
      TC: {
        title: 'Des concurrents qui reviennent, des jeunes méfiants',
        items: ['Concurrents qui réinvestissent la communication (« Les fruits c’est la vie », « Le goût du partage »)', 'défiance des jeunes envers les marques perçues comme enfantines (H)', 'allégations santé strictement encadrées'],
        figs: []
      }
    }
  };

  const MOMENTS = [
    { key: 'boost', name: 'Boost', color: '#eca21a', moment: 'Matin', sub: '+ Vitamines C, B6 & B12', flavor: 'Agrumes', bw: '19vw', icon: 'sun', need: 'J’ai besoin d’énergie pour démarrer.' },
    { key: 'focus', name: 'Focus', color: '#2f8f4e', moment: 'Après-midi', sub: '+ Ginseng rouge & Fer', flavor: 'Pomme', bw: '19vw', icon: 'target', need: 'J’ai besoin de me concentrer.' },
    { key: 'anti-stress', name: 'Anti-stress', color: '#d04a86', moment: 'Fin d’après-midi', sub: '+ Safran & Rhodiola', flavor: 'Fruits rouges', bw: '12vw', icon: 'wave', need: 'J’ai besoin de décompresser.' },
    { key: 'nuit-calme', name: 'Nuit calme', color: '#27378a', moment: 'Soir', sub: '+ Mélatonine & Mélisse', flavor: 'Pomme', bw: '14vw', icon: 'moon', need: 'J’ai besoin de bien dormir.', cls: 'nuit' }
  ];
  const DAY_TIME = { boost: 'Le matin', focus: 'L’après-midi', 'anti-stress': 'Fin d’après-midi · début de soirée', 'nuit-calme': 'Le soir' };

  // Contenu scientifique de chaque gourde
  const LAB = {
    boost: { accent: '#ffc24d', kicker: 'Vitamines & énergie', nuts: [
      { mol: 'vitc', name: 'Vitamine C', chem: 'Acide ascorbique', f: 'C₆H₈O₆ · 176,12 g/mol', role: 'Contribue à réduire la fatigue.' },
      { mol: 'vitb6', name: 'Vitamine B6', chem: 'Pyridoxine', f: 'C₈H₁₁NO₃ · 169,18 g/mol', role: 'Contribue à réduire la fatigue.' },
      { mol: 'vitb12', name: 'Vitamine B12', chem: 'Cobalamine (corrine + cobalt)', f: 'C₆₃H₈₈CoN₁₄O₁₄P · 1 355 g/mol', role: 'Contribue au métabolisme énergétique normal.' }
    ] },
    focus: { accent: '#6fe39a', kicker: 'Concentration & vitalité', nuts: [
      { mol: 'ginsenoside', name: 'Ginseng rouge', chem: 'Ginsénoside (structure simplifiée)', f: 'noyau dammarane + sucre', role: 'Plante tonique, traditionnellement associée à la vitalité mentale.' },
      { mol: 'fer', name: 'Fer', chem: 'Oligo-élément · Fe', f: 'Z = 26 · 55,845 u', role: 'Contribue aux fonctions cognitives normales.' }
    ] },
    'anti-stress': { accent: '#ff7fb4', kicker: 'Calme & équilibre', nuts: [
      { mol: 'safranal', name: 'Safran', chem: 'Safranal (arôme principal)', f: 'C₁₀H₁₄O · 150,22 g/mol', role: 'Épice précieuse, associée au bien-être émotionnel.' },
      { mol: 'salidroside', name: 'Rhodiola', chem: 'Salidroside', f: 'C₁₄H₂₀O₇ · 300,30 g/mol', role: 'Plante adaptogène, traditionnellement utilisée face au stress.' }
    ] },
    'nuit-calme': { accent: '#8fb0ff', kicker: 'Détente & sommeil', nuts: [
      { mol: 'melatonine', name: 'Mélatonine', chem: 'N-acétyl-5-méthoxytryptamine', f: 'C₁₃H₁₆N₂O₂ · 232,28 g/mol', role: 'Hormone du sommeil : contribue à réduire le temps d’endormissement.' },
      { mol: 'rosmarinique', name: 'Mélisse', chem: 'Acide rosmarinique (actif principal)', f: 'C₁₈H₁₆O₈ · 360,31 g/mol', role: 'Plante apaisante, favorise la détente du soir.' }
    ] }
  };

  const DIST = [
    ['cart', 'Grandes surfaces', 'Hypers et supermarchés (GSA), rayon compotes', '#d04a86'],
    ['car', 'Drive', 'Click & collect des grandes enseignes', '#eca21a'],
    ['vending', 'Distributeurs automatiques', 'Campus, gares, entreprises, salles de sport', '#2f8f4e'],
    ['box', 'Amazon', 'Marketplace et livraison à domicile', '#27378a'],
    ['globe', 'E-commerce', 'Site Pom’Potes Moments, abonnement possible', '#d04a86'],
    ['leaf', 'Aroma-Zone', 'Site et boutiques du partenaire', '#2f8f4e'],
    ['store', 'Commerces de proximité', 'Supérettes, épiceries, magasins de campus', '#eca21a'],
    ['fork', 'Restauration hors domicile', 'Restos U, cafétérias, snacking', '#27378a']
  ];
  const COM = [
    ['phone', 'Réseaux sociaux', 'Posts et vidéos TikTok, Instagram, BeReal, YouTube', '#d04a86'],
    ['poster', 'Affichage universitaire', 'Affiches dans les universités et écoles', '#eca21a'],
    ['play', 'Publicités', 'Spots vidéo, digital et affichage extérieur (DOOH)', '#2f8f4e'],
    ['users', 'Influence', 'Créateurs et étudiants ambassadeurs', '#27378a'],
    ['cal', 'Événements sur les campus', 'Dégustations, stands, expériences immersives', '#d04a86'],
    ['link', 'Co-branding Aroma-Zone', 'Communication croisée avec le partenaire', '#2f8f4e']
  ];

  /* ------------------------------------------------------------------
     MOTEUR DE SLIDES
  ------------------------------------------------------------------- */
  const slides = $$('.slide');
  const wipe = $('#wipe');
  const body = document.body;
  let cur = 0, busy = false;

  $('#cTot').textContent = String(slides.length).padStart(2, '0');
  const dotsEl = $('#dots');
  slides.forEach((s, i) => {
    const b = document.createElement('button');
    b.title = s.dataset.title || '';
    b.addEventListener('click', () => go(i));
    dotsEl.appendChild(b);
    // délais en cascade pour la révélation
    $$('.rv', s).forEach((el, k) => el.style.setProperty('--d', k));
  });

  const isProd = () => slides[cur].classList.contains('s-product');
  const isSwot = () => slides[cur].classList.contains('s-swot');

  function ui() {
    $('#cNow').textContent = String(cur + 1).padStart(2, '0');
    $$('button', dotsEl).forEach((b, i) => b.classList.toggle('on', i === cur));
    $('#prev').disabled = cur === 0;
    $('#next').disabled = cur === slides.length - 1;
    body.dataset.bg = slides[cur].dataset.bg;
    history.replaceState(null, '', '#' + (cur + 1));
  }

  function settle(i) { setTimeout(() => { if (cur === i) slides[i].classList.add('settled'); }, 3200); }

  function go(n, instant) {
    if (busy || n === cur || n < 0 || n >= slides.length) return;
    if (zoomOpen) closeZoom(true);
    if (prod.state !== 'overview') resetProduct(true);
    busy = true;
    const swap = () => {
      slides[cur].classList.remove('active', 'entered', 'settled');
      cur = n;
      slides[cur].classList.add('active');
      ui();
      onEnter(cur);
    };
    if (instant) { swap(); requestAnimationFrame(() => { slides[cur].classList.add('entered'); settle(cur); }); busy = false; return; }
    wipe.className = 'in';
    setTimeout(() => {
      swap();
      wipe.className = 'out';
      setTimeout(() => { slides[cur].classList.add('entered'); settle(cur); }, 180);
    }, 880);
    setTimeout(() => { wipe.className = ''; busy = false; }, 1700);
  }
  const next = () => {
    if (isProd() && prod.state !== 'overview') return;
    go(cur + 1);
  };
  const prev = () => {
    if (isProd() && prod.state !== 'overview') { prodBack(); return; }
    go(cur - 1);
  };
  $('#next').addEventListener('click', next);
  $('#prev').addEventListener('click', prev);
  $$('[data-next]').forEach(b => b.addEventListener('click', next));
  $('#replay').addEventListener('click', () => go(0));

  document.addEventListener('keydown', e => {
    if (zoomOpen) {
      if (e.key === 'Escape') closeZoom();
      else if (e.key === 'ArrowRight') stepZoom(1);
      else if (e.key === 'ArrowLeft') stepZoom(-1);
      return;
    }
    if (e.key === 'Escape') { if (isProd() && prod.state !== 'overview') prodBack(); return; }
    if (['ArrowRight', 'ArrowDown', 'PageDown', ' '].includes(e.key)) { e.preventDefault(); next(); }
    if (['ArrowLeft', 'ArrowUp', 'PageUp'].includes(e.key)) { e.preventDefault(); prev(); }
    if (e.key === 'Home') go(0);
    if (e.key === 'End') go(slides.length - 1);
  });
  let wheelLock = 0;
  window.addEventListener('wheel', e => {
    if (zoomOpen || (isProd() && prod.state !== 'overview')) return;
    const now = Date.now();
    if (now - wheelLock < 1300 || Math.abs(e.deltaY) < 30) return;
    wheelLock = now;
    e.deltaY > 0 ? next() : prev();
  }, { passive: true });
  let tx = null;
  window.addEventListener('touchstart', e => { tx = e.touches[0].clientX; }, { passive: true });
  window.addEventListener('touchend', e => {
    if (tx == null || zoomOpen || (isProd() && prod.state !== 'overview')) return;
    const dx = e.changedTouches[0].clientX - tx; tx = null;
    if (Math.abs(dx) > 70) dx < 0 ? next() : prev();
  }, { passive: true });

  function onEnter(i) {
    body.classList.remove('prod-sel', 'lab-open');
  }

  /* ------------------------------------------------------------------
     SLIDE SWOT
  ------------------------------------------------------------------- */
  const order = [];
  (function buildSwot() {
    const t = $('#swotTable');
    let h = '<div></div>';
    SWOT.cols.forEach(c => { h += `<div class="sw-colhead">${c.label}<small>(${c.sub})</small></div>`; });
    SWOT.rows.forEach(r => {
      h += `<div class="sw-row ${r.id}">${r.label}${r.key ? '<span class="star">★</span>' : ''}</div>`;
      SWOT.cols.forEach(c => {
        const id = r.id + c.id;
        order.push(id);
        const d = SWOT.cells[id];
        const txt = d.items.map(x => x.replace(/\(H\)$/, '<abbr title="Hypothèse">(H)</abbr>')).join('<span class="dotsep"> · </span>');
        h += `<div class="sw-cell ${r.key ? 'key' : ''}" data-r="${r.id}" data-id="${id}" tabindex="0" role="button" aria-label="Zoomer : ${r.label} ${c.label}"><div class="sw-txt">${txt}</div><span class="zi">${icon('zoom')}</span></div>`;
      });
    });
    t.innerHTML = h;
  })();

  const zCard = $('#zCard'), zBack = $('#zBackdrop'), swotSlide = $('.s-swot');
  let zoomOpen = false, zoomIdx = 0;
  const rectIn = el => {
    const a = el.getBoundingClientRect(), b = swotSlide.getBoundingClientRect();
    return { left: a.left - b.left, top: a.top - b.top, width: a.width, height: a.height };
  };
  const setRect = (el, r) => { el.style.left = r.left + 'px'; el.style.top = r.top + 'px'; el.style.width = r.width + 'px'; el.style.height = r.height + 'px'; };
  function zoomTarget() {
    const b = swotSlide.getBoundingClientRect();
    const w = Math.min(b.width * .88, 1280), h = Math.min(b.height * .82, 760);
    return { left: (b.width - w) / 2, top: (b.height - h) / 2 - b.height * .01, width: w, height: h };
  }
  function fillZoom(id) {
    const d = SWOT.cells[id];
    const row = SWOT.rows.find(r => r.id === id[0]);
    const col = SWOT.cols.find(c => c.id === id[1]);
    const idx = order.indexOf(id);
    const figs = d.figs.map(f => `<div class="fig"><b>${f[0]}</b><span>${f[1]}</span></div>`).join('');
    const call = d.callout ? `<div class="callout"><b>★ ${d.callout[0]}</b>${d.callout[1]}</div>` : '';
    const hasSide = figs || call;
    zCard.style.setProperty('--rc', row.color);
    zCard.innerHTML = `
      <div class="zc-bar" style="background:${row.color}"></div>
      <div class="zc-nav"><span class="cnt">${idx + 1} / ${order.length}</span>
        <button data-z="-1" aria-label="Précédent">${icon('back')}</button>
        <button data-z="1" aria-label="Suivant">${icon('arrow')}</button>
        <button data-z="0" aria-label="Fermer">${icon('x')}</button></div>
      <div class="zc-inner">
        <span class="zc-tag" style="background:${row.color}">${row.key ? '★ ' : ''}${row.label} · ${col.label}</span>
        <h3 class="zc-title">${d.title}</h3>
        <div class="zc-body ${hasSide ? '' : 'solo'}">
          <ul class="zc-list">${d.items.map(x => `<li>${x.replace(/\(H\)$/, '<abbr title="Hypothèse">(H)</abbr>')}</li>`).join('')}</ul>
          ${hasSide ? `<div class="zc-side">${figs}${call}</div>` : ''}
        </div>
      </div>`;
    $$('.zc-nav button', zCard).forEach(b => b.addEventListener('click', e => {
      e.stopPropagation();
      const v = +b.dataset.z; v === 0 ? closeZoom() : stepZoom(v);
    }));
  }
  function openZoom(id) {
    const cell = $(`.sw-cell[data-id="${id}"]`);
    zoomIdx = order.indexOf(id);
    fillZoom(id);
    zCard.classList.remove('full');
    zCard.style.transition = 'none';
    setRect(zCard, rectIn(cell));
    zCard.classList.add('on');
    void zCard.offsetWidth;
    zCard.style.transition = '';
    zBack.classList.add('on');
    zoomOpen = true;
    requestAnimationFrame(() => {
      setRect(zCard, zoomTarget());
      zCard.style.borderRadius = '30px';
      setTimeout(() => zCard.classList.add('full'), 120);
    });
  }
  function stepZoom(v) {
    zoomIdx = (zoomIdx + v + order.length) % order.length;
    const id = order[zoomIdx];
    zCard.classList.remove('full');
    setTimeout(() => { fillZoom(id); requestAnimationFrame(() => zCard.classList.add('full')); }, 260);
  }
  function closeZoom(instant) {
    if (!zoomOpen) return;
    zoomOpen = false;
    zCard.classList.remove('full');
    zBack.classList.remove('on');
    const cell = $(`.sw-cell[data-id="${order[zoomIdx]}"]`);
    if (instant) { zCard.classList.remove('on'); return; }
    setRect(zCard, rectIn(cell));
    zCard.style.borderRadius = '16px';
    setTimeout(() => { if (!zoomOpen) zCard.classList.remove('on'); }, 700);
  }
  $('#swotTable').addEventListener('click', e => { const c = e.target.closest('.sw-cell'); if (c) openZoom(c.dataset.id); });
  $('#swotTable').addEventListener('keydown', e => { if ((e.key === 'Enter') && e.target.classList.contains('sw-cell')) openZoom(e.target.dataset.id); });
  zBack.addEventListener('click', () => closeZoom());

  /* ------------------------------------------------------------------
     SLIDE JOURNÉE
  ------------------------------------------------------------------- */
  $('#dayGrid').innerHTML = MOMENTS.map((m, i) => `
    <div class="day-card ${m.cls || ''} rv" style="--c:${m.color}">
      <div class="day-time">${DAY_TIME[m.key]}</div>
      <div class="day-ic">${icon(m.icon)}</div>
      <div class="day-need">${m.need}</div>
      <div class="day-word">${m.name}</div>
    </div>`).join('');
  $$('#dayGrid .rv').forEach((el, k) => el.style.setProperty('--d', k + 4));

  /* ------------------------------------------------------------------
     SLIDE PRODUIT : boîte → gourde → intérieur de la gourde
  ------------------------------------------------------------------- */
  const stage = $('#prodStage'), prodSlide = $('.s-product'), lab = $('#lab'), backBtn = $('#backBtn');
  const prod = { state: 'overview', key: null, timers: [] };
  const later = (fn, ms) => { const t = setTimeout(fn, ms); prod.timers.push(t); return t; };
  const clearTimers = () => { prod.timers.forEach(clearTimeout); prod.timers = []; };

  stage.innerHTML = MOMENTS.map(m => `
    <div class="col ${m.cls || ''}" data-key="${m.key}" style="--c:${m.color};--bw:${m.bw}">
      <div class="col-bg"></div>
      <div class="bigword">${m.name.toUpperCase()}</div>
      <span class="moment">${m.moment}</span>
      <div class="item">
        <img class="pouch" src="assets/pouches/${m.key}.png" alt="Gourde Pom'Potes ${m.name}" draggable="false">
        <div class="box">
          <img class="box-body" src="assets/boxes/${m.key}.jpg" alt="" draggable="false">
          <img class="box-flap" src="assets/boxes/${m.key}.jpg" alt="Boîte Pom'Potes ${m.name}" draggable="false">
        </div>
      </div>
      <div class="col-info"><h3>${m.name}</h3><p>${m.sub}</p></div>
      <div class="prices">
        <div class="price price-box"><b>4,40&nbsp;€</b><span><i>Boîte de 4 gourdes</i>4 × 130 g · saveur ${m.flavor.toLowerCase()}</span></div>
        <div class="price price-one"><b>1,10&nbsp;€</b><span><i>1 gourde individuelle</i>130 g · sans sucres ajoutés</span></div>
      </div>
      <div class="click-hint">Cliquez sur la gourde pour entrer à l’intérieur ↓</div>
    </div>`).join('');

  const colEl = k => $(`.col[data-key="${k}"]`, stage);
  const setBackLabel = () => {
    $('#backLabel').textContent = prod.state === 'lab' ? 'Ressortir de la gourde' : prod.state === 'pouch' ? 'Retour aux 4 boîtes' : 'Retour';
  };
  function setSelClass(on) {
    prodSlide.dataset.sel = on ? '1' : '0';
    body.classList.toggle('prod-sel', on);
  }

  function openBox(key) {
    if (prod.state !== 'overview') return;
    clearTimers();
    prod.state = 'box'; prod.key = key;
    const c = colEl(key);
    stage.classList.add('has-sel');
    c.classList.add('sel');
    setSelClass(true);
    backBtn.classList.add('on'); setBackLabel();
    later(() => c.classList.add('open'), 1000);          // l'opercule se lève
    later(() => c.classList.add('out'), 2100);           // la gourde sort de la boîte
    later(() => { c.classList.add('solo'); prod.state = 'pouch'; setBackLabel(); }, 3400); // zoom sur la gourde
  }

  function enterLab() {
    if (prod.state !== 'pouch') return;
    clearTimers();
    prod.state = 'diving';
    const c = colEl(prod.key);
    c.classList.add('dive');
    buildLab(prod.key);
    later(() => { lab.classList.add('on'); body.classList.add('lab-open'); }, 950);
    later(() => { lab.classList.add('show'); prod.state = 'lab'; setBackLabel(); }, 1700);
  }

  function buildLab(key) {
    const m = MOMENTS.find(x => x.key === key), L = LAB[key];
    lab.style.setProperty('--ac', L.accent);
    let bubbles = '';
    for (let i = 0; i < 26; i++) {
      const s = 6 + Math.random() * 38;
      bubbles += `<i style="left:${Math.random() * 100}%;width:${s}px;height:${s}px;animation-duration:${9 + Math.random() * 14}s;animation-delay:${-Math.random() * 18}s;--dx:${(Math.random() - .5) * 90}px"></i>`;
    }
    lab.innerHTML = `
      <div class="lab-bg"></div><div class="bubbles">${bubbles}</div>
      <div class="lab-inner">
        <div class="lab-head">
          <div>
            <div class="lab-kicker">À l’intérieur de la gourde · ${L.kicker}</div>
            <div class="lab-title">${m.name}</div>
            <div class="lab-sub">${m.sub} · 130 g · sans sucres ajoutés</div>
          </div>
          <div class="lab-scale"><span class="bar"></span><br>vue microscopique<br>composition active</div>
        </div>
        <div class="nuts">
          ${L.nuts.map((n, i) => {
            const M = window.MOLS[n.mol];
            return `<div class="nut" style="--i:${i}">
              <div class="nut-no">Nº 0${i + 1}</div>
              <div class="nut-mol" style="--i:${i}"><svg viewBox="${M.vb}" preserveAspectRatio="xMidYMid meet" style="--i:${i}">${M.inner}</svg></div>
              <div class="nut-name">${n.name}</div>
              <div class="nut-chem">${n.chem}<i>${n.f}</i></div>
              <div class="nut-role">${n.role}</div>
            </div>`;
          }).join('')}
        </div>
        <div class="lab-foot"><span>Structures chimiques simplifiées, à but pédagogique</span><span>Allégations indicatives · projet étudiant</span></div>
      </div>`;
  }

  function leaveLab() {
    clearTimers();
    prod.state = 'diving';
    lab.classList.remove('show');
    later(() => { lab.classList.remove('on'); body.classList.remove('lab-open'); colEl(prod.key).classList.remove('dive'); }, 500);
    later(() => { prod.state = 'pouch'; setBackLabel(); lab.innerHTML = ''; }, 2300);
  }

  function resetProduct(instant) {
    clearTimers();
    const key = prod.key;
    lab.classList.remove('show', 'on'); body.classList.remove('lab-open');
    if (!key) { prod.state = 'overview'; return; }
    const c = colEl(key);
    const fin = () => {
      $$('.col', stage).forEach(x => x.classList.remove('sel', 'open', 'out', 'solo', 'dive'));
      stage.classList.remove('has-sel'); setSelClass(false);
      backBtn.classList.remove('on'); prod.state = 'overview'; prod.key = null; lab.innerHTML = '';
    };
    if (instant) { fin(); return; }
    prod.state = 'closing';
    c.classList.remove('dive', 'solo');
    later(() => c.classList.remove('out'), 450);
    later(() => c.classList.remove('open'), 950);
    later(() => { stage.classList.remove('has-sel'); c.classList.remove('sel'); setSelClass(false); backBtn.classList.remove('on'); }, 1500);
    later(fin, 2600);
  }

  function prodBack() {
    if (prod.state === 'lab') leaveLab();
    else if (prod.state === 'pouch') resetProduct();
    else if (prod.state === 'box') resetProduct();
  }
  backBtn.addEventListener('click', prodBack);

  stage.addEventListener('click', e => {
    const c = e.target.closest('.col'); if (!c) return;
    if (prod.state === 'overview') openBox(c.dataset.key);
    else if (prod.state === 'pouch' && e.target.closest('.pouch')) enterLab();
  });

  /* ------------------------------------------------------------------
     GRAND FORMAT / TUILES / FIN
  ------------------------------------------------------------------- */
  $('#bigGrid').innerHTML = ['boost', 'focus', 'anti-stress', 'nuit-calme'].map((k, i) =>
    `<div class="big-item" style="--n:${i}"><img src="assets/grand-format/${k}.jpg" alt="Pack grand format ${k}"></div>`).join('');

  const tiles = (data) => data.map((d, i) => `
    <div class="tile-card rv" style="--c:${d[3]}">
      <div class="tile-ic">${icon(d[0])}</div><h3>${d[1]}</h3><p>${d[2]}</p>
    </div>`).join('');
  $('#distGrid').innerHTML = tiles(DIST);
  $('#comGrid').innerHTML = tiles(COM);
  $$('#distGrid .rv, #comGrid .rv').forEach((el, i) => el.style.setProperty('--d', (i % 8) + 3));

  $('#endPouches').innerHTML = ['boost', 'focus', 'anti-stress', 'nuit-calme'].map((k, i) =>
    `<img src="assets/pouches/${k}.png" alt="" style="--n:${i};--r:${[-8, -3, 3, 8][i]}deg">`).join('');

  /* ------------------------------------------------------------------
     DÉMARRAGE
  ------------------------------------------------------------------- */
  const start = Math.min(Math.max((parseInt(location.hash.slice(1), 10) || 1) - 1, 0), slides.length - 1);
  slides[start].classList.add('active');
  cur = start; ui();
  setTimeout(() => { slides[cur].classList.add('entered'); settle(cur); }, 250);
})();
