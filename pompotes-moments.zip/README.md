# Pom'Potes Moments — présentation interactive

Site statique (HTML / CSS / JS, sans installation ni dépendance) : projet marketing
« Comment Pom'Potes peut reconquérir les 18-23 ans ? ».

## Ouvrir en local
Double-cliquez sur `index.html`, ou lancez un petit serveur :

    python3 -m http.server 8000     # puis http://localhost:8000

## Mettre en ligne avec GitHub Pages
1. Créez un dépôt : https://github.com/new (par ex. `pompotes-moments`, public).
2. Envoyez tout le contenu de ce dossier à la racine du dépôt
   (bouton « Add file » → « Upload files », ou `git push`).
3. Dans le dépôt : **Settings → Pages → Build and deployment**
   - Source : *Deploy from a branch*
   - Branch : `main` / dossier `/ (root)` → **Save**
4. Après ~1 minute, le site est en ligne sur `https://VOTRE-PSEUDO.github.io/pompotes-moments/`.

Documentation officielle : https://docs.github.com/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Utilisation pendant la présentation
- Flèches ← → (ou espace, molette, boutons en bas) : slide suivante / précédente.
- SWOT : cliquer une case pour zoomer ; flèches ‹ › dans la fiche pour passer à la case suivante ; Échap pour fermer.
- Pom'Potes Moments : cliquer une boîte → l'opercule s'ouvre, la gourde sort → cliquer la gourde pour « entrer » dedans.
  Échap ou « Retour » pour remonter d'un niveau.

## Où modifier quoi
| Élément | Fichier |
|---|---|
| Textes des slides | `index.html` |
| Contenu du SWOT, listes distribution / communication, composition des gourdes, prix | `js/main.js` (en haut du fichier) |
| Couleurs, tailles, animations | `css/style.css` |
| Dessins des molécules | `js/molecules.js` |
| Images (gourdes, boîtes, packs de 12, logos, fond bureau) | `assets/` |

Astuce : pour une vraie photo de bureau en intro, remplacez `assets/bureau.svg`
par votre image (et adaptez le nom dans `css/style.css`, règle `.bg-intro .office`).
